package com.example.springangular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAngularApplicationTests {

	@Test
	void contextLoads() {
	}

}
