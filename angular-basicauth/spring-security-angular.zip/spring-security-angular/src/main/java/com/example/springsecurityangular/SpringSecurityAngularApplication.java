package com.example.springsecurityangular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityAngularApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityAngularApplication.class, args);
	}

}
