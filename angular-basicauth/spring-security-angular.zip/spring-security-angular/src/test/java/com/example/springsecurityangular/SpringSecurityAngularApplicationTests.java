package com.example.springsecurityangular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityAngularApplicationTests {

	@Test
	void contextLoads() {
	}

}
